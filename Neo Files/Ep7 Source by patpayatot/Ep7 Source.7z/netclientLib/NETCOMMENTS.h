#pragma once

namespace NETCOMMENTS
{
	extern const char* NET_MSG_CHA_NEW_OK;
	extern const char* NET_MSG_CHA_NEW_DUP;
	extern const char* NET_MSG_CHA_NEW_MAX;
	extern const char* NET_MSG_CHA_NEW_ERROR;
};
