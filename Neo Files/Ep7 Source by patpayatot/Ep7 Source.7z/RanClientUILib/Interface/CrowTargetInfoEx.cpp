#include "StdAfx.h"
#include "CrowTargetInfo.h"
#include "ClubWindow.h"

#include "InnerInterface.h"
#include "../EngineUILib/GUInterface/BasicTextBox.h"
#include "../EngineUILib/GUInterface/BasicProgressBar.h"
#include "../EngineUILib/GUInterface/BasicButton.h"
#include "GLGaeaClient.h"
#include "UITextControl.h"
#include "GameTextControl.h"
#include "GLogicData.h"
#include "ItemSlot.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/*void CCrowTargetInfo::SetAcademy_Department ( const GLCHARLOGIC& sCharData )
{
		m_pAcademy_Department->SetOneLineText ( "Arvin Lordes <3", NS_UITEXTCOLOR::SILVER );
}*/
