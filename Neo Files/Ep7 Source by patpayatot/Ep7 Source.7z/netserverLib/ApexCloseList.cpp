#include "StdAfx.h"
#include ".\apexcloselist.h"

ApexCloseList::ApexCloseList(void)
{
}

ApexCloseList::~ApexCloseList(void)
{
}
