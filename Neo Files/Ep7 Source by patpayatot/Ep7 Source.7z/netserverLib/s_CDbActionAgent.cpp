#include "StdAfx.h"
#include "s_CDbAction.h"
#include "GLCharData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/******************************************************************************
** Agent Server Database Action Start
******************************************************************************/

