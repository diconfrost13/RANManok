///////////////////////////////////////////////////////////////////////////////
// s_CMemPooler.cpp
//
// class TCList
// class TCMemPooler
//
// * History
// 2003.03.25 jgkim Create
//
// Copyright 2002-2003 (c) Mincoms. All rights reserved.                 
// 
// * Note
//
///////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "s_cmempooler.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

namespace MEM_POOLER 
{

}